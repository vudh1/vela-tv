# Vela 2.5 — Sony Android TV launcher

Minimalist Android TV launcher, with profiles, calendar, wallpapers, optional Baby Monitor, custom volume UI, and non-destructive Sony Home access.

## GitHub production builds and TV updates

**Repository:** https://github.com/vudh1/vela-tv

- `main` is for development.
- Merging into `production` triggers GitHub Actions to compile and sign an APK, then publish `Vela-release.apk` and its SHA-256 checksum as a GitHub Release.
- **Gear → Updates → Check for updates** checks the GitHub release feed, then **Download & install** launches Android's user-approved installer. Daily metadata checks can be enabled; updates are not installed without confirmation.
- Same package ID and **same original app signing certificate** are required for in-place upgrades. New install keys cannot update a differently signed version.

**Important:** The existing `vudh1/vela-tv` repo is private. Private GitHub releases are not readable anonymously from the TV. Keep it private until ready, then either make sanitized source public, or create a public binary mirror (requires separate deployment configuration). Never store GitHub PATs inside the TV app.

## One-time setup on your Mac

1. Extract this ZIP alongside your previous Vela source folder. **Do not delete your existing signing keystore.**
2. Install/authenticate GitHub CLI (`gh auth login`) and ensure Git is installed.
3. Run `bash scripts/bootstrap-github.sh` to copy the sanitized project to GitHub `main`, configure the 4 signing secrets from the original local key, and merge the identical files to `production`. This intentionally uses Git and `gh` on your Mac only for the **first** setup.
4. In GitHub → Settings → Actions → General, allow workflow `Read and write permissions` if release creation is denied; check Actions runs for status.
5. Publish a public release feed (see privacy note). If you choose to make `vela-tv` public, verify no sensitive files are committed, then change visibility in GitHub → Settings → General → Danger Zone.
6. Once the first release is publicly available, install Vela 2.5 once on TV, using the same signing keystore, or use in-app update if the installed app already has the updater.

## Local build

```bash
export ANDROID_HOME="$HOME/Library/Android/sdk"
export JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home"
export PATH="$JAVA_HOME/bin:$PATH"
bash scripts/build.sh
bash scripts/tv.sh install 192.168.88.24
```

## Security and rollout

- Android TV requires explicit approval to install a self-update (and may request *Allow from this source* once).
- No app data or profile preferences are cleared by successful in-place upgrades.
- The original Google TV launcher remains installed for recovery.
- `.gitignore` excludes signing keys, APKs, local state, tool downloads. Confirm with `git ls-files` before changing visibility.
- Do not change the Android package ID `com.danielvu.quiethome` while deploying updates.
- No remote CI run or installation has yet been tested on this Sony TV from this environment.
